package com.projekpbo.entities;

public class BirdObstacle extends Obstacle{
    public BirdObstacle() {
        obstacleSpeed = 300;
    }
}
