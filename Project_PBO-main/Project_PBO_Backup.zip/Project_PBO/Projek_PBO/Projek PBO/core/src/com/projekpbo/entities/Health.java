package com.projekpbo.entities;

public interface Health {
    void takeDamage(int damage);
}



